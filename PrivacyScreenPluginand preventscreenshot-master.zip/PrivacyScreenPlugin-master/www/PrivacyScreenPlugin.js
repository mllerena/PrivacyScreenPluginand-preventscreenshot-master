//var exec = require('cordova/exec');

/** 
 * Not sure this will even have a JS API
 */
//exports.activate = function(arg, success, error) {
  //exec(success, error, "PrivacyScreenPlugin", "activate", [arg]);
//};
